import java.util.Scanner;

public class checkDeIdade {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		System.out.println("Insira a sua idade");
		int idade = entrada.nextInt();
		System.out.println("Insira o ano em que voc� completar� 18 anos");
		int anoDe18 = entrada.nextInt();
		if (idade >= 18) {
			System.out.println("Precisa se alistar");
		}
		else if (anoDe18 == 2023) { 
			System.out.println("Precisa se alistar");
		}
		else {
			System.out.println("N�o vai servir");
		}
		
		entrada.close();
		// TODO Auto-generated method stub
		

	}

}
