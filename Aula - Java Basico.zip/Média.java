import java.util.Scanner;
public class M�dia {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Insira o seu nome");
		String nome = sc.next();
		System.out.println("Insira a sua primeira nota");
		int nota1 = sc.nextInt();
		System.out.println("Insira a sua segunda nota");
		int nota2 = sc.nextInt();
		double media = (nota1 + nota2)/2;
		if (media >= 7) {
			System.out.println(nome + "voc� foi aprovado");
		}
		else {
			System.out.println(nome + " voc� foi reprovado");
		}
		sc.close();
		// TODO Auto-generated method stub

	}

}
