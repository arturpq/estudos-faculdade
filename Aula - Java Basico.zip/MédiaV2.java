import java.util.Scanner;
import java.util.ArrayList;

public class M�diaV2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner nota = new Scanner(System.in);
		ArrayList<Double> notas = new ArrayList<Double>();
		System.out.println("Insira o seu numero de notas");
		int numeroDeNotas = nota.nextInt();
		double soma = 0;
		int checkDeNota = 0;
		
		while (numeroDeNotas != notas.size()) {
		System.out.println("Insira a nota "+ (checkDeNota+1));
		notas.add(nota.nextDouble());
		soma = soma + notas.get(checkDeNota);
		checkDeNota = checkDeNota + 1;
		}
		double media = soma/2;
		if (media >= 7) {
			System.out.println("Voc� foi aprovado");
		}
		else {
			System.out.println("Voc� foi reprovado");
		}
		


	}

}
