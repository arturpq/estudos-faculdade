import java.util.Scanner;
public class IfElseTreino1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner num = new Scanner(System.in);
		System.out.println("Insira o numero 1");
		int num1 = num.nextInt();
		System.out.println("Insira o numero 2");
		int num2 = num.nextInt();
		int somaNum = num1 + num2;
		if (somaNum > 20) {
			somaNum = somaNum + 5;
			System.out.println(somaNum);
		}
		else { 
			somaNum = somaNum * 8;
			System.out.println(somaNum);
			}
	}

}
